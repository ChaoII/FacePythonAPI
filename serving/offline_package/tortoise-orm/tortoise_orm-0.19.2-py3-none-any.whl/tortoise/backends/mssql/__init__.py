from .client import MSSQLClient

client_class = MSSQLClient
