from .client import SqliteClient

client_class = SqliteClient
